from django.shortcuts import render, redirect, get_object_or_404

# Create your views here.
from .models import FoodItem
from django.contrib import messages

def index(request):
    featured_items = FoodItem.objects.all().order_by('-created_at')[:6]
    return render(request, 'index.html', {'featured_items': featured_items})

def about(request):
    return render(request, 'about.html')

def book(request):
    return render(request, 'book.html')


def menu(request):
    items = FoodItem.objects.all().order_by('-created_at')
    return render(request, 'menu.html', {'items': items})

def add_food_item(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        image_url = request.POST.get('image_url')
        category = request.POST.get('category')

        if name and description and price:
            FoodItem.objects.create(
                name=name,
                description=description,
                price=price,
                image_url=image_url or None,
                category=category
            )
            messages.success(request, f'"{name}" added to the menu!')
        else:
            messages.error(request, 'Please fill all required fields.')
        return redirect('menu')
    return render(request, 'foodaddform.html')   # add mode (no item)

def edit_food_item(request, item_id):
    item = get_object_or_404(FoodItem, id=item_id)
    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.description = request.POST.get('description')
        item.price = request.POST.get('price')
        item.image_url = request.POST.get('image_url') or None
        item.category = request.POST.get('category')
        item.save()
        messages.success(request, f'"{item.name}" updated successfully!')
        return redirect('menu')
    # edit mode: pass the item to the same template
    return render(request, 'foodaddform.html', {'item': item})

def delete_food_item(request, item_id):
    item = get_object_or_404(FoodItem, id=item_id)
    if request.method == 'POST':
        item_name = item.name
        item.delete()
        messages.success(request, f'"{item_name}" removed from the menu.')
    return redirect('menu')