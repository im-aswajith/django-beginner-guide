from django.db import models

class FoodItem(models.Model):
    CATEGORY_CHOICES = [
        ('burger', 'Burger'),
        ('pizza', 'Pizza'),
        ('pasta', 'Pasta'),
        ('fries', 'Fries'),
    ]

    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    image_url = models.URLField(blank=True, null=True)  # optional image URL
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='burger')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name