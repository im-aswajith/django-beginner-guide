from django.urls import path
from shop_app import views
urlpatterns = [
    path('', views.index, name='index'),
    path('about', views.about, name='about'),
    path('book', views.book, name='book'),
    path('menu/', views.menu, name='menu'),
    path('add-food-item/', views.add_food_item, name='add_food_item'),
    path('edit-food-item/<int:item_id>/', views.edit_food_item, name='edit_food_item'),
    path('delete-food-item/<int:item_id>/', views.delete_food_item, name='delete_food_item'),

]